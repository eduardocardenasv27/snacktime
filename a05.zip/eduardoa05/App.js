import { StyleSheet, Text, View, TextInput, Pressable, FlatList, Alert } from 'react-native';
import { useState, useEffect } from 'react';
import {SQLiteProvider, useSQLiteContext} from 'expo-sqlite';
import {SafeAreaProvider, SafeAreaView} from "react-native-safe-area-context";

const setupDatabase = async (database) => {
  try {
    await database.execAsync(`
      CREATE TABLE IF NOT EXISTS todos (
        todo_id INTEGER PRIMARY KEY AUTOINCREMENT,
        description TEXT
      );
      `);
    console.log('Database initialized!');
  } catch (err){
    console.log(err);
  }
}

export default function App() {
  return (
    <SQLiteProvider databaseName='todos.db' onInit={setupDatabase}>
        <TodoScreen />
    </SQLiteProvider>
  );
}

// TodoScreen component (Single screen for todo management)
const TodoScreen = () => {
    const [currentTodo, setCurrentTodo] = useState('');
    const [todoList, setTodoList] = useState([]);
    const db = useSQLiteContext();

    const addTodo = async () => {
      try{
        await db.runAsync('INSERT INTO todos (description) VALUES (?)', [currentTodo]);
        setCurrentTodo('');
        fetchTodos();
      }catch (err){
        console.log(err);
      }
    }

    const removeTodo = async (id) => {
      try{
        await db.runAsync('DELETE FROM todos WHERE todo_id = ?', [id]);
        fetchTodos();
      }catch (err){
        console.log(err);
      }
    }

    const fetchTodos = async () => {
      try {
        const results = await db.getAllAsync('SELECT * FROM todos');
        console.log(results);
        setTodoList(results);
      }catch (err){
        console.log(err);
      }
    }

    useEffect(() => {
      fetchTodos();
    }, []);

    return (
      <SafeAreaProvider>
        <SafeAreaView style={styles.container}>
            <Text style={styles.header}>Todo Manager</Text>
            
            <TextInput
                style={styles.input}
                placeholder='Enter todo'
                value={currentTodo}
                onChangeText={setCurrentTodo}
            />
            
            <Pressable style={styles.addButton} onPress={addTodo}>
                <Text style={styles.addButtonText}>Add Todo</Text>
            </Pressable>
            
            <FlatList
                data={todoList}
                keyExtractor={(item) => item.todo_id.toString()}
                renderItem={({ item }) => (
                    <View style={styles.todoItem}>
                        <Text style={styles.todoText}>{item.description}</Text>
                        <Pressable style={styles.removeButton} onPress={() => removeTodo(item.todo_id)}>
                            <Text style={styles.removeButtonText}>Delete</Text>
                        </Pressable>
                    </View>
                )}
            />
        </SafeAreaView>
      </SafeAreaProvider>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#fff',
        alignItems: 'center',
        justifyContent: 'center',
        paddingHorizontal: 20,
        paddingVertical: 40,
    },
    header: {
        fontSize: 24,
        fontWeight: 'bold',
        marginBottom: 20,
    },
    input: {
        width: '100%',
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        marginVertical: 5,
        borderRadius: 5,
    },
    addButton: {
        backgroundColor: 'blue',
        padding: 10,
        marginVertical: 10,
        width: '100%',
        borderRadius: 5,
    },
    addButtonText: {
        color: 'white',
        textAlign: 'center',
        fontSize: 18,
    },
    todoItem: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        padding: 10,
        borderBottomWidth: 1,
        borderColor: '#ccc',
        width: '100%',
    },
    todoText: {
        fontSize: 18,
    },
    removeButton: {
        backgroundColor: 'red',
        padding: 5,
        borderRadius: 5,
    },
    removeButtonText: {
        color: 'white',
    }
});
