import React, { useState, useEffect } from "react";
import { FlatList, View, Text, ActivityIndicator, Image} from 'react-native';
import styles from "./style";

const apiKey = "059b47148c00664772e56be2f2ef4022";

// COORDENASAS API
function GetCityLocation(textinput) {
  return fetch(
    `https://api.openweathermap.org/geo/1.0/direct?q=${textinput}&limit=1&appid=${apiKey}`
  )
    .then((res) => (res.ok ? res.json() : null))
    .catch((err) => {
      console.error(err);
      return null;
    });
}

// CLIMA ACTUAL API
function GetCityWeatherToday(lat, lon) {
  return fetch(
    `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=es`
  )
    .then((res) => (res.ok ? res.json() : null))
    .catch((err) => {
      console.error(err);
      return null;
    });
}

// FORECAST API
function GetCityWeatherForecast(lat, lon) {
  return fetch(
    `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric&lang=sp`
  )
    .then((res) => (res.ok ? res.json() : null))
    .catch((err) => {
      console.error(err);
      return null;
    });
}





// APLICACION PRINCIPAL

function App() {
  
  const [text, setText] = useState("Hermosillo");
  const [cityData, setCityData] = useState(null);
  const [weatherToday, setWeatherToday] = useState(null);
  const [weatherTomorrow, setWeatherTomorrow] = useState(null);
  const [weatherDayAfter, setWeatherDayAfter] = useState(null);

  useEffect(() => {
    if (!text) return;

    GetCityLocation(text).then((geoData) => {
      if (!geoData || !geoData[0]) return;
      setCityData(geoData[0]);

      const { lat, lon } = geoData[0];

      // HOY
      GetCityWeatherToday(lat, lon).then((data) => {
        if (data) setWeatherToday(data);
      });

      // MAÑANA
      GetCityWeatherForecast(lat, lon).then((data) => {
        if (!data || !data.list) return;
        setWeatherTomorrow(data.list[8]); 

        // PASAO MAÑANA :D

        setWeatherDayAfter(data.list[16]);
      });
    });
  }, [text]);

  const weatherArray = [
  { key: 'today', title: 'Clima de hoy!', data: weatherToday },
  { key: 'tomorrow', title: 'Clima de mañana!', data: weatherTomorrow },
  { key: 'dayAfter', title: 'Clima de pasado mañana!', data: weatherDayAfter },
  ];

  return (

    <div style={styles.actualbg}>
      <div style={styles.container}>
      <h2 style={styles.bigtext}>epica app de clima</h2>
      </div>
      <input style={styles.box}
        type="text"
        placeholder="Type city..."
        value={text}
        onChange={(e) => setText(e.target.value)}
      />
      <div style={{ ...styles.box2, maxHeight: '400px', overflowY: 'auto' }}>
        <FlatList
          data={weatherArray}
          keyExtractor={(item) => item.key}
          renderItem={({ item }) => (
            <div style={styles.weatherblockdisplay}>
              <View>
                <Text style={{ fontWeight: 'bold' }}>{item.title}</Text>
                <Text>
                  {item.data ? (
                    <Text>{`${item.data.main.temp}°C, ${item.data.weather[0].description}`}}</Text>
                  ) : (
                    <ActivityIndicator/>
                  )}
                </Text>
                <Image
                  source={{uri: 'https://media.tenor.com/NrvI8IElDK8AAAAj/gog-alien.gif'}}
                  style={{ width: 75, height: 75 }}
                />
              </View>
            </div>
          )}
        />
      </div>
    </div>
  );
}

export default App;

