
const styles = {
  actualbg: {
    minHeight: "100vh",
    background: "linear-gradient(to bottom, #ddf3ff, #cadcff)"
  },

  container: {
    background: "linear-gradient(to bottom, #56f2b5, #c6ffde)",
    textAlign: "center",
    padding: "2% 0%",
    fontFamily: "Helvetica"
  },

  bigtext: {
    color: "#ffffff",
    fontFamily: "Helvetica",
    textShadow: "2px 2px 4px #16ceb2"
  },

  box: {
    background: "linear-gradient(to bottom, #ffffff, #dee9ff)",
    width: "90%",
    padding: "15px 15px",
    fontSize: "16px",
    border: "2px solid #6b97ed",
    borderRadius: "5px",
    boxSizing: "border-box",
    display: "block",     
    margin: "4% auto",     
  },

    box2: {
    background: "linear-gradient(to bottom, #ffffff, #dee9ff)",
    width: "90%",
    padding: "10px 15px",
    borderRadius: "5px",
    boxSizing: "border-box",
    display: "block",    
    margin: "10% auto",    
  },

    weatherblockdisplay:  {
      padding: "50px 15px",
  },

    marcianito: {
      backgroundImage: "url('https://media.tenor.com/NrvI8IElDK8AAAAj/gog-alien.gif')"
    }

};

export default styles;
